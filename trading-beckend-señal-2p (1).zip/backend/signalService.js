/**
 * Proyecto: trading-beckend-señal-2p
 * Archivo: signalService.js
 * Autor: G.A.D.C.
 * Fecha: 2025-10-30
 * Descripción: Genera señales según RSI, WMA y SMA.
 */
export function processSignal(data) {
  const { rsi, wma, sma } = data;
  if (rsi > 70 && wma < sma) return 'Venta';
  if (rsi < 30 && wma > sma) return 'Compra';
  return 'Esperar';
}
