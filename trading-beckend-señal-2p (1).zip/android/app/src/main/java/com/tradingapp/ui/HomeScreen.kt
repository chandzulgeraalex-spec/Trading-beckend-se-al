/**
 * Proyecto: trading-beckend-señal-2p
 * Archivo: HomeScreen.kt
 * Autor: G.A.D.C.
 * Fecha: 2025-10-30
 * Descripción: Pantalla principal del bot de trading.
 */
package com.tradingapp.ui
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun HomeScreen() {
    var mode by remember { mutableStateOf("Manual") }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier.fillMaxSize().padding(20.dp)
    ) {
        Text("Bot de Trading — G.A.D.C.", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(30.dp))
        Text("Modo actual: $mode")
        Spacer(modifier = Modifier.height(20.dp))
        Button(onClick = { mode = if (mode == "Manual") "Automático" else "Manual" }) {
            Text("Cambiar a ${if (mode == "Manual") "Automático" else "Manual"}")
        }
    }
}
