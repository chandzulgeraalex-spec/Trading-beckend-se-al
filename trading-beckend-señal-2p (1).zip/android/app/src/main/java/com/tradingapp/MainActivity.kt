/**
 * Proyecto: trading-beckend-señal-2p
 * Archivo: MainActivity.kt
 * Autor: G.A.D.C.
 * Fecha: 2025-10-30
 * Descripción: Punto de inicio de la app Android.
 */
package com.tradingapp
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.tradingapp.ui.HomeScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HomeScreen() }
    }
}
