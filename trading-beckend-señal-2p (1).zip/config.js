/**
 * Proyecto: trading-beckend-señal-2p
 * Archivo: config.js
 * Autor: G.A.D.C.
 * Fecha: 2025-10-30
 * Descripción: Configuración principal de la app.
 */
export const SERVER_URL = 'https://trading-beckend-señal-2p.onrender.com';
export const ACCESS_TOKEN = 'GADC-9x72K3F1T8Z0-LCK2025';
