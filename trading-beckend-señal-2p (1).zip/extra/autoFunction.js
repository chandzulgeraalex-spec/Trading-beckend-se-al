/**
 * Proyecto: trading-beckend-señal-2p
 * Archivo: autoFunction.js
 * Autor: G.A.D.C.
 * Fecha: 2025-10-30
 * Descripción: Función extra — ejecuta operaciones automáticas.
 */
import { runBot } from '../backend/botEngine.js';
import { processSignal } from '../backend/signalService.js';
export function autoExecute(marketData, token) {
  const signal = processSignal(marketData);
  if (signal === 'Compra' || signal === 'Venta') {
    runBot(signal, token);
    console.log(`Operación ${signal} ejecutada automáticamente — G.A.D.C.`);
  } else {
    console.log('Sin señal clara. Esperando siguiente oportunidad.');
  }
}
